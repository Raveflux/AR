-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2024 at 11:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_rewards`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `badges`
--

CREATE TABLE `badges` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `badge_name` varchar(100) NOT NULL,
  `badge_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `earned_badges`
--

CREATE TABLE `earned_badges` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `badge_name` varchar(100) NOT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `posted_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reward_codes`
--

CREATE TABLE `reward_codes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(6) NOT NULL,
  `is_redeemed` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `school_id_number` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `points` int(11) DEFAULT 0,
  `user_type` enum('student','teacher') NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `birthdate`, `school_id_number`, `username`, `password`, `points`, `user_type`, `profile_picture`) VALUES
(1, 'francis', '2024-09-06', 'SCC-19-000234245', 'francis', '$2y$10$e7OcR3h0ZNEmYo8/HDutzOBk2vIQ.Za8qmvLYRo.JTCz9Dg1LwZ8i', 0, 'student', 'uploads/ew.jpg'),
(2, 'leo', '2024-09-06', 'SCC-19-0003234245', 'leo', '$2y$10$UGn25WAONnlOJo0I5w.EZ.f8c1rvzGWKg08feVW8bQWRa2YRFQmMi', 0, 'student', 'uploads/me.jpg'),
(3, 'mike', '2024-09-06', 'SCC-19-00032234245', 'mike', '$2y$10$7CrqzuLJMXXtN9ejzwWCN.l2um1/jgE61Er4sqWfCdWzc6sEP2Fse', 0, 'student', 'uploads/repu.PNG'),
(4, 'cantos', '2024-09-06', 'SCC-19-000322334245', 'cantos', '$2y$10$C1Ldsr1806G2eJ7RUeAtZOjLgcNnOeYjEPZE2G4NwMsOa6i2btQHS', 0, 'student', 'uploads/test.PNG'),
(5, 'arthur', '2024-09-06', 'SCC-19-0003322334245', 'arthur', '$2y$10$C3OchIIO2lCjMV5kTKv1c.wK3PSpuEJiBQ96Q9bo0R6az.0QUjppe', 0, 'student', 'uploads/ss.PNG'),
(6, 'rafayla', '2024-09-06', 'SCC-19-0002342452', 'rafayla', '$2y$10$xwYHAq6dxBCKdarehxJWX.SBlrjLy2N3OreKXFKhlGwCw/Iv68K1C', 0, 'student', 'uploads/8-4-2024 9;39;27 PM.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `student_actions`
--

CREATE TABLE `student_actions` (
  `student_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `points_used` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `badges`
--
ALTER TABLE `badges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `earned_badges`
--
ALTER TABLE `earned_badges`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_badge` (`student_id`,`badge_name`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posted_by` (`posted_by`);

--
-- Indexes for table `reward_codes`
--
ALTER TABLE `reward_codes`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `school_id_number` (`school_id_number`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `student_actions`
--
ALTER TABLE `student_actions`
  ADD PRIMARY KEY (`student_id`,`action_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `badges`
--
ALTER TABLE `badges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `earned_badges`
--
ALTER TABLE `earned_badges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `badges`
--
ALTER TABLE `badges`
  ADD CONSTRAINT `badges_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `earned_badges`
--
ALTER TABLE `earned_badges`
  ADD CONSTRAINT `earned_badges_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_actions`
--
ALTER TABLE `student_actions`
  ADD CONSTRAINT `student_actions_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
