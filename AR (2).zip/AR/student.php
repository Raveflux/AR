<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'student_rewards');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch student details
$sql = "SELECT name, school_id_number, points, profile_picture FROM students WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    $student = [
        'name' => 'Unknown',
        'school_id_number' => 'N/A',
        'points' => 0,
        'profile_picture' => 'default.jpg'
    ];
}

$code_error = '';
$code_class = '';
$code_value = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['code'])) {
    $entered_code = trim($_POST['code']);
    
    // Check if the code is valid and not redeemed
    $sql = "SELECT is_redeemed FROM reward_codes WHERE code=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $entered_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $code_info = $result->fetch_assoc();
        if ($code_info['is_redeemed'] == false) {
            // Update student's points
            $points = 1; // Each code is worth 1 point
            $sql = "UPDATE students SET points = points + ? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ii', $points, $student_id);
            $stmt->execute();

            // Mark the code as redeemed
            $sql = "UPDATE reward_codes SET is_redeemed=TRUE WHERE code=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $entered_code);
            $stmt->execute();

            $code_error = 'Code redeemed successfully. Points added.';
            $code_class = 'success';
        } else {
            $code_error = 'This code has already been redeemed.';
            $code_class = 'error';
        }
    } else {
        $code_error = 'Invalid code. Please try again.';
        $code_class = 'error';
    }

    $stmt->close();
}

$conn->close();

// Function to determine badge based on points
function getBadge($points) {
    if ($points >= 100) {
        return "badge_gold.png";
    } elseif ($points >= 50) {
        return "badge_silver.png";
    } elseif ($points >= 20) {
        return "badge_bronze.png";
    } else {
        return "badge_no.png";
    }
}

$badge_image = getBadge($student['points']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Page</title>
    <link rel="stylesheet" href="studentstyles.css"> <!-- Student-specific CSS -->
    <style>
        /* General styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            display: flex;
            height: 100vh;
            padding: 0;
        }

        /* Sidebar styles */
        .sidebar {
            height: 100%;
            width: 250px;
            background-color: #96140a;
            position: fixed;
            top: 0;
            left: -250px;
            transition: 0.3s;
            padding-top: 20px;
            z-index: 999;
        }

        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #c81010;
        }

        .sidebar h3 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }

        .menu-icon {
            font-size: 30px;
            cursor: pointer;
            color: #96140a;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1000;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s;
        }

        /* Profile container updated for layout */
        .profile-container {
            display: flex;
            align-items: center;
            background-color: #fff;
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 900%;
            max-width: 1000px;
            margin: 10px ;
            text-align: left;
        }

        /* Profile picture on the left */
        .profile-picture {
            margin-right: 20px; /* Add some spacing between the image and the info */
        }

        .profile-picture img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            object-fit: cover;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Information on the right */
        .profile-info {
            flex-grow: 1; /* Make this section take up the remaining space */
        }

        .profile-info h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .profile-info p {
            font-size: 18px;
            color: #333;
            margin: 5px 0;
        }

        /* Badge aligned below the info */
        .badge {
            margin-top: 20px;
        }

        /* Error/Success Message */
        .error, .success {
            color: #96140a;
            font-size: 14px;
            margin-top: 10px;
            font-weight: bold;
        }

        /* Sidebar open state */
        .sidebar-open {
            left: 0;
        }

        .content-open {
            margin-left: 250px;
        }

        /* Code input field styles */
        .code-form {
            margin-top: 20px;
            text-align: center;
        }

        .code-form input[type="text"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            width: 80%;
            max-width: 400px;
        }

        .code-form button {
            background-color: #96140a;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            margin-left: 10px;
        }

        .code-form button:hover {
            background-color: #c81010;
        }

        /* Post styles */
        .post {
            background-color: #fff;
            padding: 15px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .post img {
            max-width: 50%;
            max-height: 50%;
            border-radius: 10px;
        }

        .post h4 {
            margin: 0;
            color: #333;
        }

        .post p {
            margin: 10px 0;
        }/* Badge styles */
.badge {
    display: flex;
    justify-content: center; /* Center the badge */
    align-items: center; /* Align items vertically */
    margin-top: 20px;
}

.badge img {
    width: 100px; /* Adjust this value for smaller badge size */
    height: auto; /* Maintain aspect ratio */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Shadow effect */
}

/* Optional: If you want to change the size on hover */
.badge img:hover {
    transform: scale(1.1); /* Slightly enlarge the badge on hover */
}


    </style>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.querySelector('.content');
            sidebar.classList.toggle('sidebar-open');
            content.classList.toggle('content-open');
        }
    </script>
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="content">
        <div class="header">
            <h2>Welcome, <?php echo htmlspecialchars($student['name']); ?>!</h2>
        </div>

        <!-- Profile Container -->
        <div class="profile-container">
            <!-- Profile Picture -->
            <div class="profile-picture">
                <img src="<?php echo htmlspecialchars($student['profile_picture']); ?>" alt="Profile Picture">
            </div>
            <!-- Profile Information -->
            <div class="profile-info">
                <h3>Student Details</h3>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($student['name']); ?></p>
                <p><strong>ID Number:</strong> <?php echo htmlspecialchars($student['school_id_number']); ?></p>
                <p><strong>Points:</strong> <?php echo htmlspecialchars($student['points']); ?></p>
                <div class="badge">
                    <img src="<?php echo htmlspecialchars($badge_image); ?>" alt="Badge">
                </div>
            </div>
        </div>

       

        <!-- Home Page Post Section -->
        <h2>Latest News</h2>
        <div class="post">
            <h4>Leave No Trash Challenge</h4>
            <img src="1.jpg" alt="Post 1 Image">
            <p>Take the #LeaveNoTrash Challenge, win cool stuff!</p>
        </div>
        
    </div>

    <div class="menu-icon" onclick="toggleSidebar()">&#9776;</div>
</body>
</html>
